//
//  GaiagoApp.swift
//  Gaiago
//
//  Created by Vincenzo Broscritto on 09/10/2020.
//

//import SwiftUI
//
//@main
//internal struct GaiagoApp: App {
//    internal var body: some Scene {
//        WindowGroup {
//            ProviderListView(viewModel: ProviderViewModel())
//        }
//    }
//}
