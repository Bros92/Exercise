//
//  Endpoints.swift
//  Gaiago
//
//  Created by Vincenzo Broscritto on 11/10/2020.
//

import Foundation

internal enum Endpoints: String {
    case getFilm = "https://ghibliapi.herokuapp.com/films"
}
