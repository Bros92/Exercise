//
//  ProviderDetialsViewModel.swift
//  Gaiago
//
//  Created by Vincenzo Broscritto on 09/10/2020.
//

import Combine
import SwiftUI

internal class ProviderDetailsViewModel: ObservableObject, RequestDelegate {
    
    /// Provider details
    @Published private var provider: Provider?
    /// Stored subscriptions
    private var subscriptions = Set<AnyCancellable>()
        
    deinit {
        cancel()
    }
    
    /// Cancel subscriptions.
    /// It must call in deinit
    private func cancel() {
        for subscription in subscriptions {
            subscription.cancel()
        }
    }
    
    /// Get provider details
    /// - Parameter id: provider id
    internal func getProvider(with id: String) {
        request(method: .get, url: Endpoints.getFilm.rawValue, body: ["id": id as Any], encodingType: .urlEncoded, jsonBody: false)
            .decode(type: [Provider].self, decoder: JSONDecoder())
            .sink { value in
                switch value {
                
                case .finished, .failure(_):
                    break
                }
            } receiveValue: { [weak self] provider in
                self?.provider = provider.first
                self?.filmTitle = provider.first?.title
                self?.filmScore = provider.first?.score
                self?.filmProducer = provider.first?.producer
                self?.filmDirector = provider.first?.director
                self?.filmReleaseDate = provider.first?.releaseDate
                self?.filmDescription = provider.first?.description
            }
            .store(in: &subscriptions)
    }
    
    @Published var filmDescription: String?
    @Published var filmReleaseDate: String?
    @Published var filmScore: String?
    @Published var filmProducer: String?
    @Published var filmTitle: String?
    @Published var filmDirector: String?
}


